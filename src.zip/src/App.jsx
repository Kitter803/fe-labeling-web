import React, { useMemo, useState } from "react";
import { BrowserRouter, Navigate, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";

const demoUsers = [
  {
    email: "manager@datalabeling.local",
    password: "123456",
    name: "Trần Minh",
    role: "Manager"
  },
  {
    email: "annotator@datalabeling.local",
    password: "123456",
    name: "Lê Linh",
    role: "Annotator"
  },
  {
    email: "reviewer@datalabeling.local",
    password: "123456",
    name: "Nguyễn Quân",
    role: "Reviewer"
  },
  {
    email: "admin@datalabeling.local",
    password: "123456",
    name: "Phạm Hà",
    role: "Admin"
  }
];

export default function App() {
  const [user, setUser] = useState(() => {
    const raw = localStorage.getItem("dlabel_user");
    return raw ? JSON.parse(raw) : null;
  });
  const [error, setError] = useState("");

  const helperText = useMemo(
    () =>
      "Tài khoản demo: manager@datalabeling.local / 123456 | annotator@datalabeling.local / 123456 | reviewer@datalabeling.local / 123456 | admin@datalabeling.local / 123456",
    []
  );

  const handleLogin = (payload) => {
    const found = demoUsers.find(
      (item) => item.email === payload.email && item.password === payload.password
    );

    if (!found) {
      setError("Sai email hoặc mật khẩu. Vui lòng thử lại.");
      return false;
    }

    const nextUser = { name: found.name, role: found.role, email: found.email };
    setError("");
    setUser(nextUser);
    localStorage.setItem("dlabel_user", JSON.stringify(nextUser));
    return true;
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("dlabel_user");
  };

  const LoginRoute = () => {
    const navigate = useNavigate();

    return (
      <Login
        onLogin={(payload) => {
          const ok = handleLogin(payload);
          if (ok) {
            navigate("/dashboard");
          }
        }}
        errorMessage={error}
        helperText={helperText}
      />
    );
  };

  const ProtectedRoute = ({ children }) => {
    const location = useLocation();

    if (!user) {
      return <Navigate to="/login" state={{ from: location }} replace />;
    }

    return children;
  };

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<LoginRoute />} />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard
                user={user}
                onLogout={() => {
                  handleLogout();
                }}
              />
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

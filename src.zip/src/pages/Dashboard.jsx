import React from "react";

export default function Dashboard({ user, onLogout }) {
  return (
    <div className="dashboard">
      <header className="dash-header">
        <div>
          <div className="brand">Data labeling app</div>
          <div className="subtitle">Nền tảng quản lý gán nhãn dữ liệu</div>
        </div>
        <div className="user-meta">
          <div className="avatar">{user?.name?.slice(0, 1) || "M"}</div>
          <div>
            <div className="user-name">{user?.name || "Manager"}</div>
            <div className="user-role">{user?.role || "Manager"}</div>
          </div>
          <button className="btn-ghost" type="button" onClick={onLogout}>
            Logout
          </button>
        </div>
      </header>

      <section className="hero">
        <div>
          <h1>Xin chào, {user?.name || "Manager"}</h1>
          <p>
            Tổng quan hệ thống gán nhãn: tiến độ, chất lượng và trạng thái duyệt dữ liệu.
          </p>
        </div>
        <div className="hero-actions">
          <button className="btn-primary" type="button">Tạo dự án gán nhãn</button>
          <button className="btn-outline" type="button">Nhập bộ dữ liệu</button>
        </div>
      </section>

      <section className="stats">
        <div className="stat-card">
          <div className="stat-value">12</div>
          <div className="stat-label">Dự án đang chạy</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">86%</div>
          <div className="stat-label">Tiến độ gán nhãn</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">94%</div>
          <div className="stat-label">Chất lượng trung bình</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">1,280</div>
          <div className="stat-label">Mẫu đã duyệt</div>
        </div>
      </section>

      <section className="grid">
        <div className="panel">
          <div className="panel-title">Manager</div>
          <ul>
            <li>Quản lý dự án gán nhãn</li>
            <li>Quản lý bộ dữ liệu</li>
            <li>Thiết lập bộ nhãn và hướng dẫn</li>
            <li>Phân công công việc cho annotator</li>
            <li>Theo dõi trạng thái gán nhãn</li>
            <li>Xuất dữ liệu đã duyệt theo định dạng</li>
          </ul>
          <div className="panel-actions">
            <button className="btn-outline" type="button">Xem dự án</button>
            <button className="btn-outline" type="button">Quản lý bộ nhãn</button>
          </div>
        </div>

        <div className="panel">
          <div className="panel-title">Annotator</div>
          <ul>
            <li>Nhận nhiệm vụ được phân công</li>
            <li>Xem hướng dẫn và bộ nhãn</li>
            <li>Thực hiện gán nhãn trên dữ liệu</li>
            <li>Đánh dấu hoàn thành và gửi nộp</li>
            <li>Nhận phản hồi và chỉnh sửa</li>
          </ul>
          <div className="panel-actions">
            <button className="btn-outline" type="button">Danh sách nhiệm vụ</button>
            <button className="btn-outline" type="button">Bảng hướng dẫn</button>
          </div>
        </div>

        <div className="panel">
          <div className="panel-title">Reviewer</div>
          <ul>
            <li>Nhận danh sách dữ liệu cần kiểm duyệt</li>
            <li>Đối chiếu nhãn với hướng dẫn</li>
            <li>Phê duyệt hoặc trả về làm lại</li>
            <li>Ghi nhận loại lỗi theo danh mục</li>
          </ul>
          <div className="panel-actions">
            <button className="btn-outline" type="button">Hàng đợi kiểm duyệt</button>
            <button className="btn-outline" type="button">Báo cáo lỗi</button>
          </div>
        </div>

        <div className="panel">
          <div className="panel-title">Admin</div>
          <ul>
            <li>Quản lý người dùng</li>
            <li>Cấu hình hệ thống</li>
            <li>Quản lý nhật ký hoạt động</li>
            <li>Tuỳ chọn: AI hỗ trợ gợi ý nhãn</li>
          </ul>
          <div className="panel-actions">
            <button className="btn-outline" type="button">Quản trị người dùng</button>
            <button className="btn-outline" type="button">Cấu hình hệ thống</button>
          </div>
        </div>
      </section>

      <section className="two-col">
        <div className="panel">
          <div className="panel-title">Tổng quan chất lượng</div>
          <div className="quality-grid">
            <div>
              <div className="quality-label">Tỷ lệ đồng thuận</div>
              <div className="quality-value">92.4%</div>
            </div>
            <div>
              <div className="quality-label">Lỗi phổ biến</div>
              <div className="quality-value">Sai định danh</div>
            </div>
            <div>
              <div className="quality-label">Mẫu cần làm lại</div>
              <div className="quality-value">38</div>
            </div>
          </div>
          <button className="btn-outline" type="button">Xem báo cáo chất lượng</button>
        </div>

        <div className="panel">
          <div className="panel-title">Xuất dữ liệu</div>
          <p className="muted">
            Hỗ trợ xuất dữ liệu đã duyệt theo JSON, COCO, YOLO hoặc định dạng tuỳ chỉnh.
          </p>
          <div className="export-tags">
            <span>JSON</span>
            <span>COCO</span>
            <span>YOLO</span>
            <span>CSV</span>
          </div>
          <button className="btn-primary" type="button">Tạo gói xuất</button>
        </div>
      </section>

      <section className="panel activity">
        <div className="panel-title">Nhật ký hoạt động gần đây</div>
        <ul className="activity-list">
          <li>Annotator Linh đã nộp 120 mẫu cho dự án “Retail Shelf”.</li>
          <li>Reviewer Minh duyệt 85 mẫu và trả về 6 mẫu cần làm lại.</li>
          <li>Manager cập nhật hướng dẫn nhãn cho bộ dữ liệu “Street View”.</li>
          <li>Hệ thống AI đã gợi ý nhãn cho 340 ảnh.</li>
        </ul>
      </section>

      <style>{`
        .dashboard {
          min-height: 100vh;
          background: #f5f6fa;
          color: #0f172a;
          font-family: "Segoe UI", "Inter", system-ui, -apple-system, sans-serif;
          padding: 28px 28px 40px;
        }

        .dash-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          margin-bottom: 24px;
        }

        .brand {
          font-size: 18px;
          font-weight: 700;
        }

        .subtitle {
          font-size: 13px;
          color: #6b7280;
        }

        .user-meta {
          display: flex;
          align-items: center;
          gap: 12px;
          background: #ffffff;
          padding: 10px 14px;
          border-radius: 12px;
          box-shadow: 0 8px 18px rgba(15, 23, 42, 0.08);
        }

        .avatar {
          width: 40px;
          height: 40px;
          border-radius: 12px;
          background: #2563eb;
          color: #ffffff;
          display: grid;
          place-items: center;
          font-weight: 700;
        }

        .user-name {
          font-weight: 600;
        }

        .user-role {
          font-size: 12px;
          color: #6b7280;
        }

        .hero {
          background: #ffffff;
          border-radius: 16px;
          padding: 20px 24px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          box-shadow: 0 10px 24px rgba(15, 23, 42, 0.08);
          margin-bottom: 20px;
        }

        .hero h1 {
          margin: 0 0 6px;
          font-size: 24px;
        }

        .hero p {
          margin: 0;
          color: #6b7280;
        }

        .hero-actions {
          display: flex;
          gap: 12px;
          flex-wrap: wrap;
        }

        .stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
          gap: 16px;
          margin-bottom: 20px;
        }

        .stat-card {
          background: #ffffff;
          border-radius: 12px;
          padding: 16px;
          box-shadow: 0 8px 18px rgba(15, 23, 42, 0.08);
        }

        .stat-value {
          font-size: 20px;
          font-weight: 700;
          margin-bottom: 4px;
        }

        .stat-label {
          font-size: 12px;
          color: #6b7280;
        }

        .grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
          gap: 16px;
          margin-bottom: 20px;
        }

        .panel {
          background: #ffffff;
          border-radius: 14px;
          padding: 18px;
          box-shadow: 0 8px 18px rgba(15, 23, 42, 0.08);
        }

        .panel-title {
          font-weight: 700;
          margin-bottom: 10px;
        }

        .panel ul {
          margin: 0;
          padding-left: 18px;
          font-size: 13px;
          color: #475569;
          line-height: 1.6;
        }

        .panel-actions {
          display: flex;
          gap: 10px;
          margin-top: 14px;
          flex-wrap: wrap;
        }

        .two-col {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 16px;
          margin-bottom: 20px;
        }

        .quality-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
          gap: 12px;
          margin-bottom: 14px;
        }

        .quality-label {
          font-size: 12px;
          color: #6b7280;
        }

        .quality-value {
          font-size: 16px;
          font-weight: 600;
        }

        .export-tags {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
          margin: 12px 0 16px;
        }

        .export-tags span {
          background: #eef2ff;
          color: #4338ca;
          padding: 4px 10px;
          border-radius: 999px;
          font-size: 12px;
        }

        .activity-list {
          margin: 0;
          padding-left: 18px;
          color: #475569;
          font-size: 13px;
          line-height: 1.6;
        }

        .activity {
          margin-bottom: 20px;
        }

        .muted {
          color: #64748b;
          font-size: 13px;
        }

        .btn-primary {
          border: none;
          background: #2563eb;
          color: #ffffff;
          font-size: 13px;
          font-weight: 600;
          padding: 10px 14px;
          border-radius: 10px;
          cursor: pointer;
        }

        .btn-outline {
          border: 1px solid #c7d2fe;
          background: #eef2ff;
          color: #4338ca;
          font-size: 13px;
          font-weight: 600;
          padding: 8px 12px;
          border-radius: 10px;
          cursor: pointer;
        }

        .btn-ghost {
          border: 1px solid #e2e8f0;
          background: #ffffff;
          color: #0f172a;
          font-size: 12px;
          font-weight: 600;
          padding: 8px 12px;
          border-radius: 8px;
          cursor: pointer;
        }

        @media (max-width: 900px) {
          .dash-header {
            flex-direction: column;
            align-items: flex-start;
          }

          .user-meta {
            width: 100%;
            justify-content: space-between;
          }
        }
      `}</style>
    </div>
  );
}

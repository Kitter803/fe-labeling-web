import React, { useState } from "react";

export default function Login({ onLogin, errorMessage, helperText }) {
	const [showPassword, setShowPassword] = useState(false);
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");

	return (
		<div className="login-page">
			<div className="login-shell">
				<div className="login-left">
					<div className="app-title">Manager Login</div>
					<div className="login-card">
						<div className="card-header">
							<div className="card-title">Data labeling app</div>
							<div className="card-subtitle">
								Đăng nhập để quản lý dự án gán nhãn và vận hành hệ thống
							</div>
						</div>

						<form
							className="login-form"
							onSubmit={(event) => {
								event.preventDefault();
								onLogin?.({ email, password });
							}}
						>
							<label className="field-label" htmlFor="email">
								Email address
							</label>
							<div className="input-wrap">
								<span className="input-icon" aria-hidden="true">
									<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
										<path d="M4 6h16a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2Z" />
										<path d="m22 8-10 6L2 8" />
									</svg>
								</span>
								<input
									id="email"
									name="email"
									type="email"
									placeholder="example@email.com"
									autoComplete="email"
									required
									value={email}
									onChange={(event) => setEmail(event.target.value)}
								/>
							</div>

							<label className="field-label" htmlFor="password">
								Password
							</label>
							<div className="input-wrap">
								<span className="input-icon" aria-hidden="true">
									<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
										<rect x="4" y="10" width="16" height="10" rx="2" />
										<path d="M8 10V7a4 4 0 1 1 8 0v3" />
									</svg>
								</span>
								<input
									id="password"
									name="password"
									type={showPassword ? "text" : "password"}
									placeholder="••••••••••••" 
									autoComplete="current-password"
									required
									value={password}
									onChange={(event) => setPassword(event.target.value)}
								/>
								<button
									type="button"
									className="toggle-password"
									aria-label={showPassword ? "Ẩn mật khẩu" : "Hiển thị mật khẩu"}
									onClick={() => setShowPassword((value) => !value)}
								>
									{showPassword ? (
										<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
											<path d="M3 3l18 18" />
											<path d="M10.5 10.5a3 3 0 0 0 4.2 4.2" />
											<path d="M7.2 7.2A10.2 10.2 0 0 0 2 12c1.7 3.6 5.6 6 10 6a9.8 9.8 0 0 0 5.5-1.6" />
											<path d="M14.1 5.1A10.3 10.3 0 0 0 12 5c-4.4 0-8.3 2.4-10 6a10.9 10.9 0 0 0 3.4 4.1" />
										</svg>
									) : (
										<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
											<path d="M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6-10-6-10-6Z" />
											<circle cx="12" cy="12" r="3" />
										</svg>
									)}
								</button>
							</div>

							<div className="row-between">
								<label className="remember">
									<input type="checkbox" name="remember" />
									<span>Remember me</span>
								</label>
								<a className="link" href="/forgot-password">
									Forgot password?
								</a>
							</div>

							{errorMessage && <div className="error-text">{errorMessage}</div>}
							{helperText && <div className="helper-text">{helperText}</div>}

							<button type="submit" className="btn-primary">
								Login
							</button>
						</form>

						<div className="card-footer">
							<span>Need access?</span>
							<a className="link" href="mailto:admin@datalabeling.local">
								Contact your system administrator
							</a>
						</div>
					</div>
				</div>

				<div className="login-right">
					<div className="panel-title">Vai trò & chức năng chính</div>
					<div className="role-grid">
						<div className="role-card">
							<div className="role-name">Manager</div>
							<ul>
								<li>Quản lý dự án gán nhãn</li>
								<li>Quản lý bộ dữ liệu</li>
								<li>Thiết lập bộ nhãn và hướng dẫn</li>
								<li>Phân công, theo dõi tiến độ</li>
								<li>Theo dõi chất lượng & xuất dữ liệu</li>
							</ul>
						</div>
						<div className="role-card">
							<div className="role-name">Annotator</div>
							<ul>
								<li>Nhận nhiệm vụ được phân công</li>
								<li>Xem hướng dẫn và bộ nhãn</li>
								<li>Thực hiện gán nhãn trên dữ liệu</li>
								<li>Gửi nộp để kiểm duyệt</li>
								<li>Nhận phản hồi và chỉnh sửa</li>
							</ul>
						</div>
						<div className="role-card">
							<div className="role-name">Reviewer</div>
							<ul>
								<li>Kiểm duyệt dữ liệu đã nộp</li>
								<li>Đối chiếu với hướng dẫn</li>
								<li>Phê duyệt hoặc trả về làm lại</li>
								<li>Ghi nhận loại lỗi theo danh mục</li>
							</ul>
						</div>
						<div className="role-card">
							<div className="role-name">Admin</div>
							<ul>
								<li>Quản lý người dùng</li>
								<li>Cấu hình hệ thống</li>
								<li>Quản lý nhật ký hoạt động</li>
								<li>Tuỳ chọn: AI hỗ trợ gợi ý nhãn</li>
							</ul>
						</div>
					</div>
				</div>
			</div>

			<style>{`
				:root {
					color-scheme: light;
				}

				.login-page {
					min-height: 100vh;
					background: #2b2b2b;
					display: flex;
					align-items: center;
					justify-content: center;
					padding: 32px 20px;
					font-family: "Segoe UI", "Inter", system-ui, -apple-system, sans-serif;
					color: #1f2937;
				}

				.login-shell {
					width: min(1180px, 100%);
					background: #efefef;
					border-radius: 16px;
					box-shadow: 0 20px 60px rgba(0, 0, 0, 0.35);
					padding: 32px;
					display: grid;
					grid-template-columns: minmax(320px, 430px) minmax(280px, 1fr);
					gap: 32px;
				}

				.login-left {
					display: flex;
					flex-direction: column;
					gap: 16px;
				}

				.app-title {
					font-weight: 600;
					font-size: 18px;
					color: #4b5563;
					letter-spacing: 0.3px;
				}

				.login-card {
					background: #ffffff;
					border-radius: 14px;
					padding: 28px 28px 22px;
					box-shadow: 0 16px 40px rgba(15, 23, 42, 0.12);
					border: 1px solid #e5e7eb;
				}

				.card-header {
					text-align: center;
					margin-bottom: 18px;
				}

				.card-title {
					font-size: 20px;
					font-weight: 700;
					color: #1f2937;
					margin-bottom: 6px;
				}

				.card-subtitle {
					font-size: 13px;
					color: #6b7280;
				}

				.login-form {
					display: grid;
					gap: 14px;
				}

				.error-text {
					background: #fee2e2;
					border: 1px solid #fecaca;
					color: #991b1b;
					padding: 8px 10px;
					border-radius: 8px;
					font-size: 12px;
				}

				.helper-text {
					background: #eff6ff;
					border: 1px solid #bfdbfe;
					color: #1d4ed8;
					padding: 8px 10px;
					border-radius: 8px;
					font-size: 12px;
					line-height: 1.4;
				}

				.field-label {
					font-size: 13px;
					font-weight: 600;
					color: #4b5563;
				}

				.input-wrap {
					display: grid;
					grid-template-columns: 40px 1fr auto;
					align-items: center;
					border: 1px solid #e5e7eb;
					border-radius: 10px;
					background: #f9fafb;
					padding: 0 10px;
					height: 44px;
					gap: 6px;
				}

				.input-wrap input {
					border: none;
					outline: none;
					background: transparent;
					font-size: 14px;
					color: #111827;
					width: 100%;
				}

				.input-icon {
					width: 32px;
					height: 32px;
					border-radius: 8px;
					background: #2563eb;
					color: #ffffff;
					display: grid;
					place-items: center;
				}

				.input-icon svg {
					width: 18px;
					height: 18px;
				}

				.toggle-password {
					border: none;
					background: transparent;
					color: #6b7280;
					display: grid;
					place-items: center;
					padding: 0 6px;
					cursor: pointer;
				}

				.toggle-password svg {
					width: 18px;
					height: 18px;
				}

				.row-between {
					display: flex;
					align-items: center;
					justify-content: space-between;
					font-size: 13px;
					color: #6b7280;
				}

				.remember {
					display: flex;
					align-items: center;
					gap: 8px;
					font-size: 13px;
				}

				.link {
					color: #2563eb;
					text-decoration: none;
					font-weight: 600;
				}

				.link:hover {
					text-decoration: underline;
				}

				.btn-primary {
					border: none;
					background: #2563eb;
					color: #ffffff;
					font-size: 15px;
					font-weight: 600;
					padding: 12px 16px;
					border-radius: 10px;
					cursor: pointer;
					box-shadow: 0 12px 20px rgba(37, 99, 235, 0.25);
					transition: transform 0.15s ease, box-shadow 0.15s ease;
				}

				.btn-primary:hover {
					transform: translateY(-1px);
					box-shadow: 0 14px 24px rgba(37, 99, 235, 0.3);
				}

				.card-footer {
					margin-top: 16px;
					padding-top: 14px;
					border-top: 1px solid #e5e7eb;
					display: flex;
					gap: 6px;
					font-size: 12px;
					color: #6b7280;
					justify-content: center;
				}

				.login-right {
					display: flex;
					flex-direction: column;
					gap: 16px;
				}

				.panel-title {
					font-size: 18px;
					font-weight: 700;
					color: #1f2937;
				}

				.role-grid {
					display: grid;
					gap: 16px;
					grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
				}

				.role-card {
					background: #ffffff;
					border-radius: 12px;
					padding: 16px;
					border: 1px solid #e5e7eb;
					box-shadow: 0 8px 18px rgba(15, 23, 42, 0.08);
				}

				.role-name {
					font-weight: 700;
					margin-bottom: 8px;
					color: #1f2937;
				}

				.role-card ul {
					margin: 0;
					padding-left: 18px;
					color: #4b5563;
					font-size: 13px;
					line-height: 1.55;
				}

				@media (max-width: 980px) {
					.login-shell {
						grid-template-columns: 1fr;
					}

					.login-right {
						order: -1;
					}
				}

				@media (max-width: 540px) {
					.login-shell {
						padding: 20px;
					}

					.login-card {
						padding: 22px;
					}
				}
			`}</style>
		</div>
	);
}
